# -*- coding: utf-8 -*-
"""
@author: guardati
"""

print("Mi primer programa en Python")