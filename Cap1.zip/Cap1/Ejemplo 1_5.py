# -*- coding: utf-8 -*-
"""
@author: guardati
Ejemplo 1_5
Uso de algunas de las secuencias de escape de Python.
"""

print("\nHola otoño")  # Baja un renglón e imprime Hola otoño.
print("\\Hola otoño")  # Imprime \Hola otoño.
print("Saludo: \t¡Hola otoño!")  # Tabula horizontalmente e imprime Hola otoño.
print("\"Hola otoño\"")  # Imprime "Hola otoño".
print("\'Hola otoño\'")  # Imprime 'Hola otoño'.
print("\aHola otoño")  # Imprime Hola otoño y suena un timbre.
